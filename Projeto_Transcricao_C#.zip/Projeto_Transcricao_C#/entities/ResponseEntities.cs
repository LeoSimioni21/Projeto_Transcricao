﻿namespace Projeto_Transcricao_C_.entities
{
    public class ResponseEntities<T>
    {
        public T? Dados { get; set; }
        public string Mensagem { get; set; } = string.Empty;
        public bool Status { get; set; } = true;
    }
}
