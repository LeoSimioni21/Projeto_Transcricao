﻿namespace Projeto_Transcricao_C_.settings
{
    public class OpenAiSettings
    {
        public string ApiKey { get; set; } = string.Empty;
    }
}
